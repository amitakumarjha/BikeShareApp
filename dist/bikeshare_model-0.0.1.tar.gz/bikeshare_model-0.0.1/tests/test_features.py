
"""
Note: These tests will fail if you have not first trained the model.
"""
import sys
from pathlib import Path
file = Path(__file__).resolve()
parent, root = file.parent, file.parents[1]
sys.path.append(str(root))

import unittest
import pandas as pd
from bikeshare_model.processing.features import WeekdayImputer

class TestWeekdayImputer(unittest.TestCase):

    def setUp(self):
        # Sample data for testing
        data = {
            'dteday': ['2022-01-01', '2022-01-02', '2022-01-03', '2022-01-04'],
            'weekday': [None, 'Sun', None, 'Tue']
        }
        self.df = pd.DataFrame(data)
        self.expected_df = pd.DataFrame({
            'weekday': ['Sat', 'Sun', 'Mon', 'Tue']
        })
        self.imputer = WeekdayImputer(variable='weekday', date_var='dteday')

    def test_transform(self):
        result = self.imputer.fit_transform(self.df)
        pd.testing.assert_frame_equal(result, self.expected_df)

    def test_invalid_variable_type(self):
        with self.assertRaises(ValueError):
            WeekdayImputer(variable=123, date_var='dteday')

    def test_invalid_date_var_type(self):
        with self.assertRaises(ValueError):
            WeekdayImputer(variable='weekday', date_var=456)

    def test_missing_date_var_column(self):
        df_missing_date = self.df.drop(columns=['dteday'])
        with self.assertRaises(KeyError):
            self.imputer.fit_transform(df_missing_date)

    def test_missing_weekday_column(self):
        df_missing_weekday = self.df.drop(columns=['weekday'])
        with self.assertRaises(KeyError):
            self.imputer.fit_transform(df_missing_weekday)
